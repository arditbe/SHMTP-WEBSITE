import HttpError from '@wasp/core/HttpError.js'

export const createProject = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const { title } = args;

  const project = await context.entities.Project.create({
    data: {
      title,
      userId: context.user.id
    }
  });

  return project;
}

export const updateProject = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.Project.update({
    where: { id: args.projectId, userId: context.user.id },
    data: { title: args.newTitle }
  })
}