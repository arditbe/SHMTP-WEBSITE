import HttpError from '@wasp/core/HttpError.js'

export const getTabs = async (args, context) => {
  return [
    { label: "Ballina" },
    { label: "Rreth shkolles" },
    { label: "Stafi" },
    { label: "Drejtimet" },
    { label: "Projektet" },
    { label: "Krijuesit" }
  ];
}

export const getProject = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  const project = await context.entities.Project.findUnique({
    where: { id: args.projectId },
    include: { user: true }
  });

  if (!project) { throw new HttpError(400, `Project with id ${args.projectId} does not exist.`) }

  if (project.userId !== context.user.id) { throw new HttpError(400, `Project with id ${args.projectId} does not belong to the user.`) }

  return project;
}