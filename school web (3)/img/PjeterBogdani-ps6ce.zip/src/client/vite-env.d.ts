/// <reference types="../../.wasp/out/web-app/node_modules/vite/client" />
