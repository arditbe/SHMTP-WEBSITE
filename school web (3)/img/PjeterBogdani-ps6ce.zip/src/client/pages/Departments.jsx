import React from 'react';
import { Link } from 'react-router-dom';


export function DepartmentsPage() {
  return (
    <div className='p-4'>
      <h1 className='text-3xl font-bold mb-4'>Departments</h1>
      <p>Displays information about the departments.</p>
      <div className='mt-4'>
        <Link to='/'>Go to Home</Link>
      </div>
    </div>
  );
}