import React from 'react';
import { Link } from 'react-router-dom';


export function AboutSchool() {
  return (
    <div>
      <h1>About School</h1>
      <p>Displays information about the school.</p>
      <div className='mt-4'>
        <Link to='/'>Ballina</Link>
      </div>
      <div className='mt-4'>
        <Link to='/rreth-shkolles'>Rreth shkolles</Link>
      </div>
      <div className='mt-4'>
        <Link to='/stafi'>Stafi</Link>
      </div>
      <div className='mt-4'>
        <Link to='/drejtimet'>Drejtimet</Link>
      </div>
      <div className='mt-4'>
        <Link to='/projektet'>Projektet</Link>
      </div>
      <div className='mt-4'>
        <Link to='/krijuesit'>Krijuesit</Link>
      </div>
    </div>
  );
}