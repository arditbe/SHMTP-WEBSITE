import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@wasp/queries';

export function HomePage() {
  const { data: tabs, isLoading, error } = useQuery(getTabs);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div>
      <h1>Welcome to PjeterBogdani School</h1>
      <ul className='flex gap-x-4'>
        {tabs.map((tab) => (
          <li key={tab.id}>
            <Link to={tab.path}>{tab.title}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}