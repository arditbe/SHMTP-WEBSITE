import React from 'react';
import { Link } from 'react-router-dom';


export function Staff() {
  return (
    <div>
      <h1>Staff Page</h1>
      <p>This page displays information about the staff.</p>
      <Link to='/'>Go to Home</Link>
    </div>
  );
}