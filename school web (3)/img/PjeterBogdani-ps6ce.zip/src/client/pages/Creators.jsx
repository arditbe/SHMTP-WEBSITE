import React from 'react';
import { Link } from 'react-router-dom';


export function Creators() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Creators</h1>
      <p>This website was created by a team of talented developers.</p>
      <p>For any inquiries, please contact us at example@example.com.</p>
      <Link to="/projektet" className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-4">Go to Projects</Link>
    </div>
  );
}