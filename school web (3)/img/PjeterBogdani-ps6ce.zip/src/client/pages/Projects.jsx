import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';
import getUserProjects from '@wasp/queries/getUserProjects';
import createProject from '@wasp/actions/createProject';
import updateProject from '@wasp/actions/updateProject';

export function Projects() {
  const { data: projects, isLoading, error } = useQuery(getUserProjects);
  const createProjectFn = useAction(createProject);
  const updateProjectFn = useAction(updateProject);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const [newProjectTitle, setNewProjectTitle] = useState('');

  const handleCreateProject = () => {
    createProjectFn({ title: newProjectTitle });
    setNewProjectTitle('');
  };

  const handleUpdateProject = (projectId, newTitle) => {
    updateProjectFn({ projectId, newTitle });
  };

  return (
    <div className=''>
      <div className='flex gap-x-4 py-5'>
        <input
          type='text'
          placeholder='New Project'
          className='px-1 py-2 border rounded text-lg'
          value={newProjectTitle}
          onChange={(e) => setNewProjectTitle(e.target.value)}
        />
        <button
          onClick={handleCreateProject}
          className='bg-blue-500 hover:bg-blue-700 px-2 py-2 text-white font-bold rounded'
        >
          Add Project
        </button>
      </div>
      <div>
        {projects.map((project) => (
          <div
            key={project.id}
            className='py-2 px-2 flex items-center hover:bg-slate-100 gap-x-2 rounded'
          >
            <input
              type='text'
              value={project.title}
              onChange={(e) => handleUpdateProject(project.id, e.target.value)}
              className='px-1 py-2 border rounded text-lg'
            />
          </div>
        ))}
      </div>
      <div className='mt-4'>
        <Link to='/'>Ballina</Link>
        <Link to='/rreth-shkolles'>Rreth shkolles</Link>
        <Link to='/stafi'>Stafi</Link>
        <Link to='/drejtimet'>Drejtimet</Link>
        <Link to='/krijuesit'>Krijuesit</Link>
      </div>
    </div>
  );
}